package company;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        BudgetManager budgetManager = new BudgetManager();

        Category foodCategory = new Category("Food");

        Expense expense1 = new Expense("Groceries", 50.0, foodCategory) {
            @Override
            public String getType() {
                return "Expense";
            }
        };
        Expense expense2 = new Expense("Eating out", 30.0, foodCategory) {
            @Override
            public String getType() {
                return "Expense";
            }
        };
        Income income1 = new Income("Salary", 1000.0, new Category("Income"));
        Income income2 = new Income("Freelance", 500.0, new Category("Income"));

        budgetManager.addExpense(income1);
        budgetManager.addExpense(income2);

        budgetManager.addExpense(expense1);
        budgetManager.addExpense(expense2);

        double totalExpenses = budgetManager.calculateTotalExpenses();

        System.out.println("Total expenses: $" + totalExpenses);

        List<Expense> expenses = budgetManager.getExpenses();
        System.out.println("Expenses:");
        for (Expense expense : expenses) {
            System.out.println("Name: " + expense.getName());
            System.out.println("Amount: $" + expense.getAmount());
            System.out.println("Category: " + expense.getCategory().getName());
            System.out.println();
        }
    }
}
