package company;
import java.util.ArrayList;
import java.util.List;

public class BudgetManager {
    private List<Expense> expenses = new ArrayList<>();


    public void addExpense(Expense expense) {

        expenses.add(expense);
    }
    public BudgetManager() {
    }
    public double calculateTotalExpenses() {
        double total = 0;
        for (Expense expense : expenses) {
            total += expense.getAmount();
        }
        return Math.round(total * 100.0)/ 100.0;
    }

    public List<Expense> getExpenses() {

        return expenses;
        }
    public void removeExpense(String expenseName) {
        expenses.removeIf(expense -> expense.getName().equals(expenseName));
    }

        }
