package company;

    public class Income extends Expense {
        public Income(String name, double amount, Category category) {
            super(name, amount, category);
        }

        @Override
        public String getType() {
            return "Income";
        }

    }




