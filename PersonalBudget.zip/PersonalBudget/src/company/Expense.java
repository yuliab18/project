package company;
import java.util.Random;
public abstract class Expense {
    private String name;
    private double amount;
    private Category category;

    public Expense(String name, double v, Category category) {
        this.name = name;
        this.category = category;
        generateRandomAmount();
    }

    private void generateRandomAmount() {
        Random random = new Random();
        amount = random.nextDouble() * 100;
    }

    public abstract String getType();

    public String getName() {
        return name;
    }

    public double getAmount() {
        return Math.round(amount * 100.0) / 100.0;
    }

    public Category getCategory() {
        return category;
    }

}








