package company;

public abstract class Transaction {
    private String name;
    private double amount;
    private Category category;

    public Transaction(String name, double amount, Category category) {
        this.name = name;
        this.amount = amount;
        this.category = category;
    }


    public String getName() {
        return name;
    }

    public double getAmount() {
        return amount;
    }

    public Category getCategory() {
        return category;
    }

    public abstract String getType();
}

